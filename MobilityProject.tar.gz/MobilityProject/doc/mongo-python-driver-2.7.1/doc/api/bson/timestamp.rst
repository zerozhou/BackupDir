:mod:`timestamp` -- Tools for representing MongoDB internal Timestamps
======================================================================
.. versionadded:: 1.5

.. automodule:: bson.timestamp
   :synopsis: Tools for representing MongoDB internal Timestamps
   :members:
