#!/usr/bin/env python
#encoding:utf=8
import pymongo

conn = pymongo.Connection(host='127.0.0.1',port=27017)
db = conn.ChatRoom

ipAddressTable = db.IPTable
conRecordTable = db.ContentRecordTable

ipAddressTable.update({"RouterID":'host1'},{"$set":{"IpAddress":'192.168.1.1'}}, True, False)

conRecordTable.update( \
    {"ContentName":"/ustc/pics/p.png"},\
    { '$set':{"OldLocation":"RouterID-1","NewLocation":"RouterID-2"}},\
    True, 
    False
    )

if __name__ == '__main__':

    print 'print IPAddressTable:\n'
    for item in ipAddressTable.find():
        if item["RouterID"] == 'host1':
            print item
        else:
            print item

    print '\nprinting CMRT:\n'
    for data in conRecordTable.find():
        if data['ContentName'] == '/ustc/pics/p.png':
            print data
        else:
            print data
