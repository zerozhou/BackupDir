from pyccn import CCN, Name, ContentObject, KeyLocator, SignedInfo
#import time

key = CCN.getDefaultKey()
keyLocator = KeyLocator(key)

def GenerateSignedInfo( key, keyLocator):
    siInfo = SignedInfo()
    siInfo.publisherPublicKeyDigest = key.publicKeyID
    siInfo.freshnessSeconds = 3
    siInfo.keyLocator = keyLocator
    #siInfo.timeStamp = b'0x22'   #time.time()
    return siInfo

def GenerateContentObject(name, content):
    co = ContentObject()
    co.name = Name(name)
    co.content = content
    co.signedInfo = GenerateSignedInfo(key, keyLocator)
    co.sign(key)  # what is the function going to do? 
    #co.signature = ????
    return co

if __name__ == '__main__':
    print '\n GenerateSignedInfo:\n'
    si = GenerateSignedInfo(key, keyLocator)
    print si
    print '\v===========================\n content:\n'
    co = GenerateContentObject("/ustc/123/", "haha, 2B")
    print co
