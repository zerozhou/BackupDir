#!/usr/bin/env python
import pyccn
from pyccn import CCN, Name, ContentObject, SignedInfo, KeyLocator, Closure
import pymongo, thread, time


#CONNECTION TO DataBase
conn = pymongo.Connection(host='127.0.0.1',port=27017)
db = conn.ChatRoom
account = db.Account

#CCN Element
key = CCN.getDefaultKey()
keyLocation = KeyLocator(key)
#topoInfo
name_topoInfo_get=Name("ccnx:/topoInfo/getIPAddress/")
name_topoInfo_result=Name("ccnx:/contentInfo/getIPAddress/result/")
#test
routerID = 'hostname'
IPAddress = '192.168.1.1'

ccn_handle = CCN()  # sender handle, CCN handle
#receiver_handle = CCN() #receiver handle, CCN handle


class PutTopoInfoClosure(Closure):
    def __init__(self):
        Closure.__init__(self)

    def upcall(self, kind, upcallInfo):

        global ccn_handle, name_topoInfo_get, name_topoInfo_result

        print ('Sender handle:')
        print (upcallInfo)
        if name_topoInfo_get == upcallInfo.Interest.name:
            print upcallInfo.Interest.name
            pass

        if name_topoInfo_result == upcallInfo.Interest.name:
            print upcallInfo.Interest.name
            name = name_topoInfo_get
            content = str(routerID) + '/' + str(IPAddress)
            conObject= self.GenerateContent(name, content)
            self.SendContent(conObject)
            print ('send contnet object = ', conObject)
		#	print "put done"
 	return pyccn.RESULT_INTEREST_CONSUMED


	#make a content packet use 'name' and 'content'
    def GenerateContent(self, name, content):
        global key, keyLocation, routerID 
        conObject = ContentObject() # content = {name, content, signature, signedInfo}

        conObject.name = pyccn.Name(name)   #name
        conObject.content = content         # content 
        conObject.signedInfo = SignedInfoClass.SignedInfo(key, keyLocation)  #signedInfo
        conObject.sign(key)   #signature
        return conObject

class SignedInfoClass(object):
    def __init__(self, key, keyLocation):
        self.key = key
        self.keyLocation = keyLocation

    def SignedInfo(self): #signedInfo  {publisherPublicKeyDigest, Timetamp, keyLocator?, Type?, fressnessSeconds?, finalBlockID?,}
        siInfo = SignedInfo()
        siInfo.publisherPublicKeyDigest = key.publicKeyID
        siInfo.type = pyccn.CONTENT_DATA
        siInfo.freshnessSeconds = 3
        siInfo.keyLocator = keyLocation

        return siInfo


    def SendContent (self, contentObject):
        global ccn_handle
        ccn_handle.put(contentObject)


# ThreadPutTopoInfoClosure is used to handle different interest from Controller

def ThreadPutTopoInfo():
    global ccn_handle, name_contentInfo, event_loop
    putTopoInfoClosure = PutTopoInfoClosure()
    #ccn_handle = CCN()  # CCN handle
    ccn_handle.setInterestFilter(name_topoInfo_get, putTopoInfoClosure)
    event_loop = pyccn.EventLoop(ccn_handle)
    event_loop.run()


def StartThreadPutTopoInfo():
	thread.start_new_thread(ThreadPutTopoInfo,())
	

if __name__ == '__main__':

	StartThreadPutTopoInfo()
	while(1):	
		time.sleep(30)




