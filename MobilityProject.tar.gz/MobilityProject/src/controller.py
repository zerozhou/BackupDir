#!/usr/bin/env python
import _pyccn
from pyccn import CCN, Name, Interest, ContentObject, SignedInfo, KeyLocator, Closure
import pymongo, thread, time


#CONNECTION TO DataBase
conn = pymongo.Connection(host='127.0.0.1',port=27017)
db = conn.ChatRoom
account = db.Account

#CCN Element
key = CCN.getDefaultKey()
keyLocation = KeyLocator(key)
#topoInfo
name_topoInfo_get=Name("ccnx:/topoInfo/getIPAddress/")
name_topoInfo_result=Name("ccnx:/contentInfo/getIPAddress/result/")
#test
routerID = 'hostname'
IPAddress = '192.168.1.1'

ccn_handle = CCN()  # sender handle, CCN handle
#receiver_handle = CCN() #receiver handle, CCN handle


class GetTopoInfoClosure(Closure):
    def __init__(self):
        Closure.__init__(self)

    # what is the upcall funciton used to do ???????
    def upcall(self, kind, upcallInfo):

        global ccn_handle, name_topoInfo_get, name_topoInfo_result
        print ('Get TopoInfo:')
        print (upcallInfo)
        topoInfo_content = upcallInfo.ContentObject.content
        print topoInfo_content

        topoInfo_name = upcallInfo.ContentObject.name
        print topoInfo_name

        if name_topoInfo_get == topoInfo_name:
            index = self.ParseContent(topoInfo_content)
            routerID = topoInfo_content[0::index]
            iPAddress = topoInfo_content[index+1:]
            db.Account.update({'RouterID':routerID}, {"$set":{'IPAddress':iPAddress}}, True, False)
            print 'update DataBase,' + routerID + iPAddress
                    
        print "get done"
 	return pyccn.RESULT_OK


	#make a content packet use 'name' and 'content'
    def ParseContent(self,content):
        index = 0
        letter = '/'
        while index < len(content):
            if content[index] == letter:
                return index
            index += 1
        return -1

class ExpressInterest_GetTopoInfo():
    def __init__(self, name):
        self.name = name

    def GenerateInterest(self):
        interest = Interest()
        interest.name = self.name
        interest.minSuffixComponents = 2
        interest.maxSuffixComponents = 4
        interest.publisherPublicKeyDigest = key.publicKeyID
        interest.exclude = None
        interest.scope = 1
        interest.interestLifetime = 30.0
        interest.nonce = b'ustc'

        return interest
    def SenderInterest(self, interest):
        pass
        


# ThreadPutTopoInfoClosure is used to handle different interest from Controller

def ThreadGetTopoInfo():
    global ccn_handle, name_contentInfo, event_loop
    getTopoInfoClosure = GetTopoInfoClosure()
    #ccn_handle = CCN()  # CCN handle
    event_loop = pyccn.EventLoop(ccn_handle, getTopoInfoClosure)
    event_loop.run()


def StartThreadGetTopoInfo():
	thread.start_new_thread(ThreadGetTopoInfo,())
	

if __name__ == '__main__':

	StartThreadGetTopoInfo()
	while(1):	
		time.sleep(30)




