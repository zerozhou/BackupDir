#!/usr/bin/env python
import pyccn
from pyccn import CCN, Name, ContentObject, Interest, SignedInfo, KeyLocator, Closure
import pymongo, thread, time


#interest::Name=ccnx:/topoInfo/get_IPAddress
#name_getIPAddress = Name("ccnx:/topoInfo/get_IPAddress/")


#CONNECTION TO DataBase
conn = pymongo.Connection(host='127.0.0.1',port=27017)
db = conn.ChatRoom
account = db.Account

#CCN Element
controller_key = CCN.getDefaultKey()
controller_keyLocation = KeyLocator(controller_key)

name_topoInfo_put=Name("ccnx:/contentInfo/putNewContent/")
name_contentInfo_get=Name("ccnx:/contentInfo/getNewContent/")

sender_handle = CCN()  # sender handle, CCN handle
receiver_handle = CCN() #receiver handle, CCN handle



class ReceiverClosure(Closure):
    def upcall(self, kind, upcallInfo): 
        global receiver_handle, name_contentInfo_put, upcall_called, event_loop
        print ("Receive Closure:")
        print (upcallInfo)

        print("#Receive# Got response %d" % kind)
        if ( kind == 4 ):
            raise AssertionError("Got timeout")
        upcall_called = True
        event_loop.stop()
        return pyccn.RESULT_OK


class SenderClosure(Closure):

    def upcall(self, kind, upcallInfo):

        global sender_handle, name_getIPAddress, controller_key, controller_keyLocation, routerID, interest_name_prefix 
        print ('Sender handle:')
        print (upcallInfo)
		# analysis the routerID  according to the interest_name_prefix_contentInfo
        #about contentInfo
        interest_name_prefix=upcallInfo.Interest.name[0:2]
        routerID=upcallInfo.Interest.name[2:3]
	
		#handle register request   
        #Interest::Name = ccnx:/contentInfo/newContent/ + str(routerID)
        if interest_name_prefix == pyccn.Name("ccnx:/contentInfo/putNewContent/"):
            name= 'ccnx:/contentInfo/newContent/'+str(routerID)
            content='Hi,'+str(routerID)+', I will get the new Content right now!'
            co= self.GenerateContent(name, content)
            r = sender_handle.put(co)
            print ('put(co) = ', r)
		#	print "put done"

            #send Interest to get new content name
            name=pyccn.Name('ccnx:/contentInfo/getNewContentFrom/'+str(routerID))
            contentInfo=self.SendInterest(name)
            if contentInfo is None:
                print ('contentInfo is None')
            else:
                print contentInfo.name
                print contentInfo.content
		count=0 #register process: add / update the contentInfo
		for item in db.Account.find():
			if item["ContentName"] == contentInfo.content:
			#update the database
			#db.Account.update({"ContentName":contentInfo.content},{"$set":{"NewLocation":str(routerID)}})
				count = count+1
			#feedback information to router
				name= 'ccnx:/contentInfo/newContent/update/result'+str(routerID)
				content = 'Name already exist and update successfully1'
				print "Name already existst and update successfully!"
				conObject= self.GenerateContent(name, content)
				sender_handle.put(conObject)

            # the ContentName is a new one
		if count == 0:
			db.Account.insert({"ContentName":contentInfo.content,"OldLocation":str(routerID),"NewLocation":str(routerID)})
			name= 'ccnx:/contentInfo/newContent/addition/result'+str(routerID)
			content = 'ContentName has already added to CMRT'
			print "ContentName has already added to CMRT"
			conObject = self.GenerateContent(name, content)
			sender_handle.put(conObject)

 		return pyccn.RESULT_INTEREST_CONSUMED

	#send interest using 'name_param', return the reveived content
	def SendInterest(self, name_param,timeout=3000):
		print "start send interest"
		interest_limit = pyccn.Interest(childSelector = 1, answerOriginKind = pyccn.AOK_NONE)
		name= name_param
		print name
		print "=============="
		handle = pyccn.CCN()
        #return what?  content is data ???
		content = handle.get(name, interest_limit, timeout)
		return content

	#make a content packet use 'name' and 'content'
	def GenerateContent(self, name, content_data):
		conObject = ContentObject()
		conObject.name = pyccn.Name(name)
		conObject.content = content_data

		si = SignedInfo()
		si.publisherPublicKeyDigest =controller_key.publicKeyID
		si.type = pyccn.CONTENT_DATA
		si.freshnessSeconds = 5
		si.keyLocator = controller_keyLocation
		conObject.signedInfo = si
		conObject.sign(controller_key)
		return conObject

upcall_called = False
event_loop = pyccn.EventLoop(sender_handle, receiver_handle)

# thread1 is used to handle different request from client
def ThreadContentInfo():
	global sender_handle, name_contentInfo, event_loop
	senderclosure = SenderClosure()
	#sender_handle = CCN()  # CCN handle
	sender_handle.setInterestFilter(name_contentInfo_put, senderclosure)
	event_loop.run()


def ControllerThreadContentInfo():
	thread.start_new_thread(ThreadContentInfo,())
	

if __name__ == '__main__':

	ControllerThreadContentInfo()
	while(1):	
		time.sleep(30)




