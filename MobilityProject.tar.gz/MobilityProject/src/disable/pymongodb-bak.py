#!/usr/bin/env python
#encoding:utf=8
import pymongo


conn = pymongo.Connection(host='127.0.0.1',port=27017)
#connection to database
db = conn.ChatRoom
#连接聚集
ipAddressTable = db.Account
conRecordTable = db.Account

#查看聚集的一条记录
#db.Account.find_one()
#db.Account.find_one({"UserName":"keyword"})
#查看聚集的字段
#db.Account.find_one({},{"UserName":1,"Email":1}){u'UserName': u'libing', u'_id': ObjectId('4ded95c3b7780a774a099b7c'), u'Email': u'libing@35.cn'}
#db.Account.find_one({},{"UserName":1,"Email":1,"_id":0}){u'UserName': u'libing', u'Email': u'libing@35.cn'}
#查看聚集的多条记录
#for item in db.Account.find():
 #       item
#for item in db.Account.find({"UserName":"libing"}):
        #item["UserName"]
#添加记录
#db.Account.insert({"RouterID":'host1',"IpAddress":'192.168.1.1'})
#db.Account.insert({"RouterID":'host2',"IpAddress":'192.168.1.2'})
#db.Account.insert({"RouterID":'host3',"IpAddress":'192.168.1.3'})
ipAddressTable.update({"RouterID":"host1"},{"$set":{"IpAddress":"192.168.1.1"}}, True, False)

#db.Account.remove({'RouterID':'host1'}) 
#db.Account.remove() 
print '\v'
#db.Account.save({"RouterID":"host4",'IpAddress':'192.168.1.5'})
#删除记录
for data in ipAddressTable.find():
    if data['RouterID'] == 'host1':
        print data
    else:
        print data
#db.Account.remove()   -- 全部删除
#db.Test.remove({"UserName":"keyword"})
