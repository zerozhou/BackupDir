#!/usr/bin/env python

import pyccn
#from pyccn import CCN, Name, Interest, ContentObject, SignedInfo, Key, KeyLocator, Closure, _pyccn
from pyccn import CCN, Name, ContentObject, SignedInfo,  KeyLocator, Closure, _pyccn
import os, socket, thread, time
#import pymongo

class RepoSocketPublisher(pyccn.Closure):
	def __init__(self, repo_port = None):
		if not repo_port:
			if not os.environ.has_key('CCNR_STATUS_PORT'):
				raise Exception("CCNR_STATUS_PORT not defined and no repo port specified")

			repo_port = os.environ['CCNR_STATUS_PORT']

		self.repo_dest = ('127.0.0.1', int(repo_port))

		self.sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
		self.sock.connect(self.repo_dest)

	def put(self, content):
		self.sock.send(_pyccn.dump_charbuf(content.ccn_data))


class SenderClosure(Closure):

	def __init__(self):
		Closure.__init__(self)

	def upcall(self, kind, upcallInfo):
		global sender_handle, n_1, k_1, kl_1, my_own_name, my_own_passwd,publisher

		#print("client closure:")
		#print(upcallInfo.Interest.name)

		if upcallInfo.Interest.name == pyccn.Name('ccnx:/ndn_video_conference/check/whether/online'+'/'+str(content_input_name)+'/'+str(content_input_passwd)):
			name=pyccn.Name('ccnx:/ndn_video_conference/check/whether/online'+'/'+str(content_input_name)+'/'+str(content_input_passwd))
			#print name
			content='Faru'
			co=make_content(name,content)
			publisher = RepoSocketPublisher()
			publisher.put(co)
			

		return pyccn.RESULT_INTEREST_CONSUMED

	
def make_content(name, content):
	co = ContentObject()
	co.name = pyccn.Name(name)
	co.content = content
	
	si = SignedInfo()
	si.publisherPublicKeyDigest = k_1.publicKeyID
	si.type = pyccn.CONTENT_DATA
	si.freshnessSeconds = 5
	si.keyLocator = kl_1
	co.signedInfo = si
	co.sign(k_1)
	return co

def SendInterest(name_param, timeout=3000):		
	print "start send interest"
	i1 = pyccn.Interest(childSelector = 1, answerOriginKind = pyccn.AOK_NONE)
	name= name_param
	#print name
	#print "=============="
	handle = pyccn.CCN()
	co1 = handle.get(name, i1,timeout)
	return co1

def client_register(content_input_name_param, content_input_passwd_param):
	print "client_register"
	global content_input_name,content_input_passwd
	content_input_name=content_input_name_param
	content_input_passwd=content_input_passwd_param

	name = pyccn.Name('ccnx:/ndn_video_conference/register/request'+'/'+str(content_input_name)+'/'+str(content_input_passwd))
	co=SendInterest(name)
	
	if co is None:
		print ('get nothing1')

	if co is not None:
		name = pyccn.Name('ccnx:/ndn_video_conference/register/result'+'/'+str(content_input_name)+'/'+str(content_input_passwd))
		co1=SendInterest(name)
		if co1 is None:
			print "no content returned"
		else:
			print co1.content





# the loop thread in client, to handle the incoming interest
def loop_client(content_input_name_param, content_input_passwd_param):
	global content_input_name,content_input_passwd,my_own_name, my_own_passwd,sender_handle, n_1
	
	content_input_name=content_input_name_param
	content_input_passwd=content_input_passwd_param

	my_own_name=content_input_name_param
	my_own_passwd=content_input_passwd_param

	senderclosure = SenderClosure()
	sender_handle = CCN()
	sender_handle.setInterestFilter(n_1, senderclosure)
	event_loop = pyccn.EventLoop(sender_handle)
	event_loop.run()


def client_register_thread1(content_input_name_param, content_input_passwd_param):
	thread.start_new_thread(client_register, (content_input_name_param, content_input_passwd_param))


if __name__ == '__main__':
	global n_1, publisher
	
	k_1 = CCN.getDefaultKey()	
	kl_1 = KeyLocator(k_1)
	n_1 = Name("ccnx:/ndn_video_conference/")

	publisher = RepoSocketPublisher()

	operation_kind=raw_input("Which operation you want to conduct?  | register | login | launch | join | invite |  :")
	
	if operation_kind == "register":
		#n_1 = Name("ccnx:/ndn_video_conference/register")
		content_input_name_param=raw_input("input name:  ")
		content_input_passwd_param=raw_input("input passwd:  ")
		
		client_register_thread1(content_input_name_param, content_input_passwd_param)
		client_loop_thread(content_input_name_param, content_input_passwd_param)
		
		while(1):
			time.sleep(30)



