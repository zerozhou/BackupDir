#include <stdio.h>
extern int a;

void printfun2()
{
    printf("printfun2 print a = %d\n",a);
}

