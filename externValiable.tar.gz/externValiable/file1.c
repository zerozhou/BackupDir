#include <stdio.h>
extern int a;

void printfun1()
{
    printf("printfun1 print a = %d\n",a);
}

