#include "file1.h"
#include "file2.h"
int a =10;
int main()
{
    printfun1();
    printfun2();
    return 0;
}
